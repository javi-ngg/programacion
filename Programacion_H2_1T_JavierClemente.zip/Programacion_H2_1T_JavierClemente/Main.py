#Importamos el menu
from Menu import menu
#Llamamos a la función del menu
menu()