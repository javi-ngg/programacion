from Funciones import registrar_cliente, ver_clientes, realizar_compra, consultar_pedido

# Menú principal actualizado
def menu():
    while True:
        print("\n--- Menú ---")
        print("1. Registrar cliente")
        print("2. Ver clientes registrados")  # Nueva opción
        print("3. Realizar compra")
        print("4. Consultar pedido")
        print("5. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            registrar_cliente()
        elif opcion == "2":
            ver_clientes()  # Llamada a la nueva función
        elif opcion == "3":
            realizar_compra()
        elif opcion == "4":
            consultar_pedido()
        elif opcion == "5":
            print("Saliendo...")
            break
        else:
            print("Opción inválida.")
