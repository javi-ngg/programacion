# Estructuras de datos principales
# Diccionario para almacenar clientes, pedidos y lista predefinida de productos con sus precios
clientes = {}
pedidos = {}
productos = {
    "1": {"nombre": "Producto A", "precio": 100},
    "2": {"nombre": "Producto B", "precio": 200},
    "3": {"nombre": "Producto C", "precio": 300},
}

# Función para registrar un cliente
def registrar_cliente():
    print("\n--- Registro de Cliente ---")
    # Solicita datos básicos del cliente
    nombre = input("Nombre completo: ")
    direccion = input("Dirección: ")
    telefono = input("Teléfono: ")
    correo = input("Correo electrónico: ")
    id_cliente = input("ID único (DNI/ID): ")

    # Verifica que el ID del cliente no esté registrado
    if id_cliente in clientes:
        print("Error: El ID ya está registrado.")
        return

    # Almacena los datos del cliente en el diccionario
    clientes[id_cliente] = {
        "nombre": nombre,
        "direccion": direccion,
        "telefono": telefono,
        "correo": correo,
    }
    print("Registro exitoso.")


# Función para ver todos los clientes registrados
def ver_clientes():
    print("\n--- Clientes Registrados ---")
    # Verifica si hay clientes en el sistema
    if not clientes:
        print("No hay clientes registrados.")
        return

    # Recorre el diccionario de clientes y muestra los datos de cada uno
    for id_cliente, info in clientes.items():
        print(f"ID: {id_cliente}")
        print(f"  Nombre: {info['nombre']}")
        print(f"  Dirección: {info['direccion']}")
        print(f"  Teléfono: {info['telefono']}")
        print(f"  Correo: {info['correo']}")
        print("-" * 30)


# Función para realizar una compra
def realizar_compra():
    print("\n--- Realizar Compra ---")
    # Solicita el ID del cliente que realiza la compra
    id_cliente = input("Ingrese su ID de cliente: ")

    # Verifica que el cliente esté registrado
    if id_cliente not in clientes:
        print("Error: Cliente no registrado.")
        return

    # Muestra los productos disponibles
    print("\nProductos disponibles:")
    for codigo, info in productos.items():
        print(f"{codigo}: {info['nombre']} - ${info['precio']}")

    # Solicita los códigos de los productos a comprar
    seleccion = input("Ingrese los códigos de productos separados por comas: ").split(",")
    total = 0
    detalles = []

    # Procesa los productos seleccionados
    for codigo in seleccion:
        codigo = codigo.strip()
        if codigo in productos:
            producto = productos[codigo]
            total += producto["precio"]  # Suma el precio del producto al total
            detalles.append(producto["nombre"])  # Añade el producto a la lista de detalles
        else:
            print(f"Producto con código {codigo} no encontrado.")  # Mensaje para productos inválidos

    # Verifica si se seleccionaron productos válidos
    if total == 0:
        print("No se realizó ninguna compra.")
        return

    # Genera un número único para el pedido y lo guarda en el diccionario
    numero_pedido = len(pedidos) + 1
    pedidos[numero_pedido] = {
        "cliente": id_cliente,
        "productos": detalles,
        "total": total,
    }
    print(f"Compra realizada exitosamente. Número de pedido: {numero_pedido}")

# Función para consultar un pedido
def consultar_pedido():
    print("\n--- Consultar Pedido ---")
    # Solicita el número de pedido a consultar
    numero_pedido = int(input("Ingrese el número de pedido: "))

    # Verifica que el pedido exista
    if numero_pedido not in pedidos:
        print("Error: Pedido no encontrado.")
        return

    # Obtiene los detalles del pedido y del cliente que lo realizó
    pedido = pedidos[numero_pedido]
    cliente = clientes[pedido["cliente"]]

    # Muestra los detalles del pedido
    print("\nDetalles del Pedido:")
    print(f"Cliente: {cliente['nombre']} ({cliente['direccion']})")
    print(f"Productos: {', '.join(pedido['productos'])}")
    print(f"Total: ${pedido['total']}")
