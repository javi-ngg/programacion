<?php
$host = "localhost";
$user = "root";  
$pass = "28octubre06";     
$dbname = "streamweb";

$conn = new mysqli($host, $user, $pass, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>