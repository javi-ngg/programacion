document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("registroForm").addEventListener("submit", function (event) {
        event.preventDefault();

        let nombre = document.getElementById("nombre").value.trim();
        let email = document.getElementById("email").value.trim();
        let edad = parseInt(document.getElementById("edad").value, 10);
        let planBase = document.getElementById("planBase").value;
        let paquetes = Array.from(document.querySelectorAll("input[name='paquetes[]']:checked")).map(el => el.value);
        let duracion = document.getElementById("duracion").value;

        // Validaciones
        if (!nombre || !email || isNaN(edad)) {
            alert("Por favor, complete todos los campos.");
            return;
        }

        if (!validateEmail(email)) {
            alert("El correo electrónico no es válido.");
            return;
        }

        if (edad < 18 && paquetes.some(p => p !== "Infantil")) {
            alert("Los menores de 18 años solo pueden contratar el Pack Infantil.");
            return;
        }

        if (planBase === "Basico" && paquetes.length > 1) {
            alert("El Plan Básico solo permite un paquete adicional.");
            return;
        }

        if (paquetes.includes("Deporte") && duracion !== "anual") {
            alert("El Pack Deporte solo puede ser contratado si la duración es anual.");
            return;
        }

        // Enviar datos al servidor
        fetch("procesar_registro.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nombre, email, edad, planBase, paquetes, duracion })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.mensaje);
            if (data.exito) {
                document.getElementById("registroForm").reset();
            }
        })
        .catch(error => console.error("Error:", error));
    });
});

// Función para validar email
function validateEmail(email) {
    let re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}





function modificarUsuario(id, planBase, paquetes, duracion) {
    fetch("modificar_usuario.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, planBase, paquetes, duracion })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.mensaje);
        location.reload(); // Recargar la página para ver los cambios
    })
    .catch(error => console.error("Error:", error));
}



function eliminarUsuario(id) {
    fetch("eliminar_usuario.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.mensaje);
        location.reload(); // Recargar la página para actualizar la lista
    })
    .catch(error => console.error("Error:", error));
}



fetch("listar_usuarios.php")
    .then(response => response.json())
    .then(data => {
        console.log("Usuarios Registrados:", data);
    })
    .catch(error => console.error("Error:", error));