<?php
header("Content-Type: application/json");
include "db.php"; // Conexión a la BD

$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["exito" => false, "mensaje" => "Datos inválidos"]);
    exit;
}

$nombre = trim($data["nombre"]);
$email = trim($data["email"]);
$edad = intval($data["edad"]);
$planBase = $data["planBase"];
$paquetes = $data["paquetes"];
$duracion = $data["duracion"];

// Validaciones
if (empty($nombre) || empty($email) || !$edad) {
    echo json_encode(["exito" => false, "mensaje" => "Todos los campos son obligatorios."]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["exito" => false, "mensaje" => "Correo electrónico inválido."]);
    exit;
}

// Restricciones de paquetes
if ($edad < 18 && array_diff($paquetes, ["Infantil"])) {
    echo json_encode(["exito" => false, "mensaje" => "Los menores de 18 años solo pueden contratar el Pack Infantil."]);
    exit;
}

if ($planBase == "Basico" && count($paquetes) > 1) {
    echo json_encode(["exito" => false, "mensaje" => "El Plan Básico solo permite un paquete adicional."]);
    exit;
}

if (in_array("Deporte", $paquetes) && $duracion != "anual") {
    echo json_encode(["exito" => false, "mensaje" => "El Pack Deporte solo puede ser contratado si la duración es anual."]);
    exit;
}

// Insertar usuario en la BD
$stmt = $conn->prepare("INSERT INTO usuarios (nombre, email, edad, plan_base, duracion) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("ssiss", $nombre, $email, $edad, $planBase, $duracion);

if ($stmt->execute()) {
    $usuario_id = $stmt->insert_id;

    // Insertar paquetes adicionales
    if (!empty($paquetes)) {
        $stmt_paquete = $conn->prepare("INSERT INTO suscripciones (usuario_id, paquete) VALUES (?, ?)");
        foreach ($paquetes as $paquete) {
            $stmt_paquete->bind_param("is", $usuario_id, $paquete);
            $stmt_paquete->execute();
        }
        $stmt_paquete->close();
    }

    echo json_encode(["exito" => true, "mensaje" => "Usuario registrado correctamente"]);
} else {
    echo json_encode(["exito" => false, "mensaje" => "Error al registrar usuario"]);
}

$stmt->close();
$conn->close();
?>

