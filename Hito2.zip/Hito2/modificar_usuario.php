<?php
header("Content-Type: application/json");
include "db.php"; // Conexión a la base de datos

$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["exito" => false, "mensaje" => "Datos inválidos"]);
    exit;
}

$id = intval($data["id"]);
$planBase = $data["planBase"];
$paquetes = $data["paquetes"];
$duracion = $data["duracion"];

// Validar que el usuario existe
$checkUser = $conn->prepare("SELECT edad FROM usuarios WHERE id = ?");
$checkUser->bind_param("i", $id);
$checkUser->execute();
$result = $checkUser->get_result();
$usuario = $result->fetch_assoc();

if (!$usuario) {
    echo json_encode(["exito" => false, "mensaje" => "Usuario no encontrado"]);
    exit;
}

$edad = $usuario["edad"];

// Validaciones
if ($edad < 18 && array_diff($paquetes, ["Infantil"])) {
    echo json_encode(["exito" => false, "mensaje" => "Los menores de 18 años solo pueden contratar el Pack Infantil."]);
    exit;
}

if ($planBase == "Basico" && count($paquetes) > 1) {
    echo json_encode(["exito" => false, "mensaje" => "El Plan Básico solo permite un paquete adicional."]);
    exit;
}

if (in_array("Deporte", $paquetes) && $duracion != "anual") {
    echo json_encode(["exito" => false, "mensaje" => "El Pack Deporte solo puede ser contratado si la duración es anual."]);
    exit;
}

// Actualizar el plan base y duración
$stmt = $conn->prepare("UPDATE usuarios SET plan_base = ?, duracion = ? WHERE id = ?");
$stmt->bind_param("ssi", $planBase, $duracion, $id);

if ($stmt->execute()) {
    // Eliminar los paquetes actuales del usuario
    $deleteStmt = $conn->prepare("DELETE FROM suscripciones WHERE usuario_id = ?");
    $deleteStmt->bind_param("i", $id);
    $deleteStmt->execute();
    
    // Insertar nuevos paquetes seleccionados
    if (!empty($paquetes)) {
        $stmtPaquete = $conn->prepare("INSERT INTO suscripciones (usuario_id, paquete) VALUES (?, ?)");
        foreach ($paquetes as $paquete) {
            $stmtPaquete->bind_param("is", $id, $paquete);
            $stmtPaquete->execute();
        }
        $stmtPaquete->close();
    }

    echo json_encode(["exito" => true, "mensaje" => "Usuario actualizado correctamente"]);
} else {
    echo json_encode(["exito" => false, "mensaje" => "Error al actualizar usuario"]);
}

$stmt->close();
$conn->close();
?>