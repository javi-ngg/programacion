<?php
header("Content-Type: application/json");
include "db.php";

$result = $conn->query("SELECT u.id, u.nombre, u.email, u.plan_base, u.duracion, GROUP_CONCAT(s.paquete) AS paquetes 
                        FROM usuarios u 
                        LEFT JOIN suscripciones s ON u.id = s.usuario_id 
                        GROUP BY u.id");

$usuarios = [];
while ($row = $result->fetch_assoc()) {
    $usuarios[] = $row;
}

echo json_encode($usuarios);
$conn->close();
?>