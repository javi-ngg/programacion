-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS streamweb;
USE streamweb;

-- Crear la tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    edad INT NOT NULL,
    plan_base ENUM('Basico', 'Estandar', 'Premium') NOT NULL,
    duracion ENUM('mensual', 'anual') NOT NULL
);

-- Crear la tabla de suscripciones (paquetes adicionales)
CREATE TABLE IF NOT EXISTS suscripciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    paquete ENUM('Deporte', 'Cine', 'Infantil') NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Insertar algunos datos de prueba
INSERT INTO usuarios (nombre, email, edad, plan_base, duracion) VALUES 
('Juan Pérez', 'juan@email.com', 25, 'Estandar', 'mensual'),
('Ana García', 'ana@email.com', 30, 'Premium', 'anual');

INSERT INTO suscripciones (usuario_id, paquete) VALUES 
(1, 'Cine'),
(2, 'Deporte'),
(2, 'Infantil');	